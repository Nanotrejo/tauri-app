import logging

import yaml
from asgi_correlation_id import correlation_id_filter

"""
CTE. to add a log group to RositaLoggerAdapter.
"""
ADAPTER_GROUP = 'GROUP'


def logger_starter(log_conf_path: str) -> []:
    """
    Configure customlogger from dictionary.

    @param log_conf_path: path to logging .yml configuration file.
    @return: dictionary with configuration to use in python logging.config.dictConfig()
    """
    with open(log_conf_path, 'r') as file:
        config = yaml.safe_load(file.read())
        config['filters'] = {'correlation_id': {'()': correlation_id_filter(uuid_length=32)}}
        return config


class RositaLoggerAdapter(logging.LoggerAdapter):
    """
    Adapter for ROSITA logging.
    Add logging-group to ROSITA traces.

    @return: logger instance to use as usual.
    """

    def process(self, msg, kwargs):
        return '[%s] %s' % (self.extra[ADAPTER_GROUP], msg), kwargs
