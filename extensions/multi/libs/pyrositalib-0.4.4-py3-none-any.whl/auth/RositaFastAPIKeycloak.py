import functools

from fastapi.security import OAuth2PasswordBearer
from fastapi_keycloak import FastAPIKeycloak
from pattern.Singleton import Singleton


class RositaFastAPIKeycloak(FastAPIKeycloak, metaclass=Singleton):

    def __init__(self, server_url: str, client_id: str, client_secret: str, realm: str, admin_client_secret: str,
                 callback_uri: str, token_url: str, admin_client_id: str = "admin-cli"):
        self.token_url = token_url
        super(RositaFastAPIKeycloak, self).__init__(server_url, client_id, client_secret, realm, admin_client_secret,
                                                    callback_uri)

    @functools.cached_property
    def user_auth_scheme(self) -> OAuth2PasswordBearer:
        """ Returns the auth scheme to register the endpoints with swagger

        Returns:
            OAuth2PasswordBearer: Auth scheme for swagger
        """
        return OAuth2PasswordBearer(tokenUrl=self.token_url)
