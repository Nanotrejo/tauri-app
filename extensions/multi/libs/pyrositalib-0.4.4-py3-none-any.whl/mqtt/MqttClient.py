import logging

import paho.mqtt.client as mqtt
from paho.mqtt import subscribe
from pattern.Singleton import Singleton


class MqttCacheClient(mqtt.Client, metaclass=Singleton):
    """
    Class that will be the responsible for intercepting mqtt messages.
    """

    """
    Mqtt logger.
    """
    __log_mqtt: logging.Logger

    def __init__(self, host=None, port=None, client_id=None, log_mqtt=None, user=None, password=None, connect=None):
        """
        Mqtt Rosita client constructor.
        Allows to connect with connect param.

        param host: mqtt broker host.
        param port: mqtt broker port.
        param client_id: mqtt client id.
        param log_mqtt: logger instance to trace mqtt.
        param user: user name.
        param password: password.
        param connect: if true connection will be done.
        """
        super().__init__(client_id)
        if log_mqtt is not None:
            self.__log_mqtt = log_mqtt
        else:
            self.__log_mqtt = logging.getLogger()

        if connect is not None and connect:
            if user is not None or password is not None:
                self.username_pw_set(user, password)
                self.__auth = {'username': user, 'password': password}
            else:
                self.__log_mqtt.warning('Mqtt configuration warning. No user or password')
            self.__log_mqtt.info('Connecting to mqtt broker')
            self.__host = host
            self.__port = port
            self.connect_and_loop()

    def connect_and_loop(self):
        """
        Connect mqtt and start connection loop.
        """
        self.connect(self.__host, self.__port, 60)
        self.loop_start()

    def subscribe_to_callback(self, topic: str, callback_function):
        """
        Create a subscription to a topic with a callback function.

        Callback example:
        def on_message_print(client, userdata, message):
            print("%s %s" % (message.topic, message.payload))

        To subscribe a list of topics use a list with topic and q0:
        Ex: [("my/topic", 0), ("another/topic", 2)]

        param topic: topic to subscribe.
        param callback_function: function to launch to handle a message.
        """
        subscribe.callback(callback_function, topic, hostname=self.__host, auth=self.__auth)

    def on_connect(self, mqttc, obj, flags, rc):
        self.__log_mqtt.info("rc: %s", str(rc))

    def on_connect_fail(self, mqttc, obj):
        self.__log_mqtt.info("Mqtt connection failed")

    def on_publish(self, mqttc, obj, mid):
        self.__log_mqtt.info("mid: %s", str(mid))

    def on_subscribe(self, mqttc, obj, mid, granted_qos):
        self.__log_mqtt.info("Subscribed: %s %s", str(mid), str(granted_qos))

    def on_log(self, mqttc, obj, level, string):
        self.__log_mqtt.info(string)
