from typing import List

from pattern.Singleton import Singleton

import redis
from .RedisConstants import REDIS_EVENT_CHANEL_GADGETS


class RedisManager(metaclass=Singleton):
    """
    Redis cache manager.
    Access and modify cache instance.
    """

    def __init__(self, host=None, port=None):
        if host is None or port is None:
            # TODO log error de la librería.
            print('Error creating redis client. No host or port provided.')

        """
        Redis client.
        """
        self.client = redis.Redis(
            decode_responses=True,
            host=host,
            port=port)

    def get_variable_value(self, low_level_var_name):
        """
        Get variable value in cache.

        @:param low_level_var_name: cache name for variables (ex: "cache.string.name.for.variable")
        :return: value for requested variable in cache.
        """
        return self.client.get(low_level_var_name)

    def set_variable_value(self, low_level_var_name, low_level_var_value):
        """
        Set variable value in cache.

        :param low_level_var_name: cache name for variables (ex: "cache.string.name.for.variable")
        :param low_level_var_value: cache value to write in cache.
        """
        self.client.set(low_level_var_name, low_level_var_value)

    def set_gadgets_value(self, low_level_var_name, low_level_var_value):
        """
        Set variable value in cache and publish associated redis event in gadgets.

        :param low_level_var_name: cache name for variables (ex: "cache.string.name.for.variable")
        :param low_level_var_value: cache value to write in cache.
        """
        self.client.set(low_level_var_name, low_level_var_value)
        self.client.publish(REDIS_EVENT_CHANEL_GADGETS, low_level_var_name)

    def get_raw_data(self, raw_keys: List[str]) -> dict:
        """
        Get raw data from cache.
        Iterates over all cache string elements to obtain them in raw format.
        Ex: {"cache.string.name.for.variable" : value}

        :param raw_keys: dict of cache keys to retrieve.
        :return: raw data in dictionary format with cache information.
        """
        raw_values = self.client.mget(raw_keys)
        raw_data_dict = dict(zip(raw_keys, raw_values))
        return raw_data_dict

    def get_all_raw_data(self) -> dict:
        """
        Get all raw data from cache.
        Iterates over all cache string elements to obtain them in raw format.
        Ex: {"cache.string.name.for.variable" : value}

        :return: raw data in dictionary format with cache information.
        """
        raw_data_dict = {}
        is_lecture_done = False
        cursor = 0
        while not is_lecture_done:
            cache_response = self.client.scan(cursor=cursor, count=50)
            cursor = cache_response[0]
            raw_keys = cache_response[1]
            raw_values = self.client.mget(raw_keys)
            raw_data_dict.update(dict(zip(raw_keys, raw_values)))
            is_lecture_done = cursor == 0

        return raw_data_dict
