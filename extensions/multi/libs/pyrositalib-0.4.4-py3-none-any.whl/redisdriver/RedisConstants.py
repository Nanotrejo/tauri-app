"""
Redis event chanel for gadgets.
"""
REDIS_EVENT_CHANEL_GADGETS = 'gadgets'
