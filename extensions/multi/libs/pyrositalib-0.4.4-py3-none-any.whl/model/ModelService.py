from typing import List
from xml.etree import ElementTree

from pattern.Singleton import Singleton
from xsdata.formats.dataclass.context import XmlContext
from xsdata.formats.dataclass.parsers import XmlParser

from .ModelConstants import XML_ATTRIBUTE_CACHE, XML_ATTRIBUTE_MQTT


class ModelService(metaclass=Singleton):
    """
    Access to model information from xml configuration file.
    """

    def __init__(self, xml_path=None, modelo=None):
        """
        Constructor.

        :param xml_path: path to xml file with model configuration.
        """
        # Path to xml configuration file.
        self.__xml_configuration_path = xml_path
        # List of cache names from xml configuration file attributes.
        self.__cache_names = self.get_all_cache_names()
        # Current model instance
        self.__current_model = self.get_current_model(modelo)

    @property
    def cache_names(self):
        return self.__cache_names

    @property
    def current_model(self):
        return self.__current_model

    def get_current_model(self, modelo):
        """
        Get current model properties from xml configuration file.
        Contains all configuration properties and example values.

        :param modelo: model object structure to parse xml file.
        :return: Modelo with example data and configuration properties.
        """
        context = XmlContext()
        parser = XmlParser(context=context)
        model = parser.parse(self.__xml_configuration_path, modelo)
        return model

    def get_cache_mqtt_names(self) -> dict:
        """
        From xml configuration, get a dict with mqtt name for each cache variable.
        Ex: {"modelo.bombas.dp01.active": "bionet/bombas/dp01/active"}

        :return: dict with cache-mqtt names.
        """
        topics = self.get_current_model_topics_by_attribute(XML_ATTRIBUTE_MQTT)
        mqtt_names = {}
        for topic in topics:
            mqtt_names.update({topic.get(XML_ATTRIBUTE_CACHE): topic.get(XML_ATTRIBUTE_MQTT)})
        return mqtt_names

    def get_all_cache_names(self) -> List[str]:
        """
        From xml configuration, get a list with all cache variables.

        :return: list with cache names.
        """
        topics = self.get_current_model_topics_by_attribute(XML_ATTRIBUTE_CACHE)
        cache_names = []
        for topic in topics:
            cache_names.append(topic.get(XML_ATTRIBUTE_CACHE))
        return cache_names

    def get_current_model_topics_by_attribute(self, attribute: str):
        """
        Find all xml elements with requested attribute.

        :param attribute: name of attribute field to search.
        :return: list of xml topics.
        """
        tree = ElementTree.parse(self.__xml_configuration_path)
        root = tree.getroot()
        topics = root.findall(".//*[@%s]" % attribute)
        return topics

    def get_attributes_searching_attribute(self, attribute: str, variables_return: List[str]) -> List[str]:
        """
        From xml configuration, get a dict with the names of the searched attribute and all the list variables inside.
        Example: get_attributes_searching_attribute('mqtt', ('script', 'mqtt', 'cache', 'type'))
        return: {'script': 'ss1', 'mqtt': 'bionet/ss/01', 'cache': 'softsensors.softsensor01', 'type': 'float'}

        :return: list with attributes.
        """
        topics = self.get_current_model_topics_by_attribute(attribute)
        atrributes = {}
        for topic in topics:
            blind = AttributeObject()
            for variable in variables_return:
                setattr(blind, variable, topic.get(variable))
            atrributes.update({topic.get(attribute): blind})
        return atrributes


class AttributeObject:
    """
    Object class to return a better structure of variables without nested dicts
    """
    pass
