"""
Cache name for variables attribute in xml configuration file.
"""
XML_ATTRIBUTE_CACHE = 'cache'

"""
Mqtt name for variables attribute in xml configuration file.
"""
XML_ATTRIBUTE_MQTT = 'mqtt'
